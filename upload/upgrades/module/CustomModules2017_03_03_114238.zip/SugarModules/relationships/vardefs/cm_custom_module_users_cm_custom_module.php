<?php
// created: 2017-03-03 11:42:38
$dictionary["cm_custom_module"]["fields"]["cm_custom_module_users"] = array (
  'name' => 'cm_custom_module_users',
  'type' => 'link',
  'relationship' => 'cm_custom_module_users',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'side' => 'right',
  'vname' => 'LBL_CM_CUSTOM_MODULE_USERS_FROM_USERS_TITLE',
);
