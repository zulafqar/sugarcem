<?php
// created: 2017-03-03 10:08:40
$dictionary["cm_cm_custom_module"]["fields"]["cm_cm_custom_module_users"] = array (
  'name' => 'cm_cm_custom_module_users',
  'type' => 'link',
  'relationship' => 'cm_cm_custom_module_users',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'side' => 'right',
  'vname' => 'LBL_CM_CM_CUSTOM_MODULE_USERS_FROM_USERS_TITLE',
);
